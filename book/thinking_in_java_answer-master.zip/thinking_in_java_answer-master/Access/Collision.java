// access/Collision.java
// TIJ4 Chapter Access, Exercise 2, page 217
/* Take the code fragments in this section and turn them into a program and 
* verify that collisions do occur.
*/
import net.mindview.simple.*;
import java.util.*;
 
public class Collision {
	public static void main(String[] args) {
		// Vector v = new Vector(); // ambiquous collision
		net.mindview.simple.Vector v1 = new net.mindview.simple.Vector();
		java.util.Vector v2 = new java.util.Vector();
	}
}
